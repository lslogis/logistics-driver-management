-- AlterTable
ALTER TABLE "loading_points" ADD COLUMN     "remarks" TEXT;
