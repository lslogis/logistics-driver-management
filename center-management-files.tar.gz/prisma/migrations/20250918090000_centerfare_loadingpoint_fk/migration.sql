-- Migration superseded by earlier schema adjustments.
SELECT 1;
