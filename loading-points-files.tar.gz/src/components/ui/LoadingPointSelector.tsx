'use client'

import React, { useState, useEffect } from 'react'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import { cn } from '@/lib/utils'

interface LoadingPoint {
  id: string
  name: string | null
  centerName: string
  loadingPointName: string
  lotAddress?: string | null
  roadAddress?: string | null
  isActive: boolean
}

interface LoadingPointSelectorProps {
  value?: string
  onValueChange: (loadingPointId: string) => void
  className?: string
  placeholder?: string
}

export function LoadingPointSelector({ 
  value, 
  onValueChange, 
  className,
  placeholder = "센터를 선택하세요" 
}: LoadingPointSelectorProps) {
  const [loadingPoints, setLoadingPoints] = useState<LoadingPoint[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    const fetchLoadingPoints = async () => {
      try {
        setLoading(true)
        const response = await fetch('/api/loading-points')
        
        if (!response.ok) {
          throw new Error('센터 목록을 불러오지 못했습니다')
        }
        
        const data = await response.json()
        setLoadingPoints(data.data || [])
      } catch (err) {
        console.error('LoadingPoints fetch error:', err)
        setError(err instanceof Error ? err.message : '알 수 없는 오류가 발생했습니다')
      } finally {
        setLoading(false)
      }
    }

    fetchLoadingPoints()
  }, [])

  const selectedLoadingPoint = loadingPoints.find(lp => lp.id === value)

  if (loading) {
    return (
      <div className={cn("h-11 w-full rounded-lg border-2 border-gray-300 bg-gray-50 animate-pulse", className)} />
    )
  }

  if (error) {
    return (
      <div className={cn("h-11 w-full rounded-lg border-2 border-red-300 bg-red-50 flex items-center px-4 text-sm text-red-600", className)}>
        오류: {error}
      </div>
    )
  }

  return (
    <Select 
      value={value || ''} 
      onValueChange={onValueChange}
    >
      <SelectTrigger className={className}>
        <SelectValue placeholder={placeholder}>
          {selectedLoadingPoint ? (
            <span className="flex items-center gap-2">
              <span className="font-medium">{selectedLoadingPoint.name || selectedLoadingPoint.centerName}</span>
              {selectedLoadingPoint.lotAddress && (
                <span className="text-sm text-gray-500">({selectedLoadingPoint.lotAddress})</span>
              )}
            </span>
          ) : (
            placeholder
          )}
        </SelectValue>
      </SelectTrigger>
      <SelectContent>
        {loadingPoints.length === 0 ? (
          <SelectItem value="" disabled>
            등록된 센터가 없습니다
          </SelectItem>
        ) : (
          loadingPoints
            .filter(lp => lp.isActive)
            .map((loadingPoint) => (
              <SelectItem key={loadingPoint.id} value={loadingPoint.id}>
                <div className="flex items-center justify-between w-full">
                  <span className="font-medium">{loadingPoint.name || loadingPoint.centerName}</span>
                  {loadingPoint.lotAddress && (
                    <span className="text-sm text-gray-500 ml-2">
                      {loadingPoint.lotAddress}
                    </span>
                  )}
                </div>
              </SelectItem>
            ))
        )}
      </SelectContent>
    </Select>
  )
}