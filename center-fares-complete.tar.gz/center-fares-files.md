# 센터요율 관련 파일 목록

## 압축 파일: center-fares-complete.tar.gz (36.6KB)

### 포함된 파일들:

#### 1. 페이지 및 API
- `center-fares/page.tsx` - 메인 센터요율 관리 페이지
- `api-center-fares/route.ts` - 센터요율 API 라우트 (GET, POST)
- `api-center-fares/[id]/route.ts` - 개별 센터요율 API 라우트 (PUT, DELETE)

#### 2. 컴포넌트 (centerFares/)
- `SimpleCenterFareCreateModal.tsx` - 요율 생성 모달
- `SimpleCenterFareEditModal.tsx` - 요율 수정 모달 
- `SimpleCenterFareDeleteDialog.tsx` - 요율 삭제 확인 다이얼로그
- `SimpleFareCalculatorDrawer.tsx` - 요율 계산기 드로어
- `SimpleFiltersBar.tsx` - 필터 바
- `SimpleImportModal.tsx` - Excel 가져오기 모달
- `ExportButton.tsx` - Excel 내보내기 버튼
- `CenterFareCreateModal.tsx` - 구버전 생성 모달
- `CenterFareEditModal.tsx` - 구버전 수정 모달
- `CenterFareDeleteDialog.tsx` - 구버전 삭제 다이얼로그
- `CenterFarePolicyDrawer.tsx` - 구버전 정책 드로어
- `CenterFareTable.tsx` - 구버전 테이블
- `FareCalculatorDrawer.tsx` - 구버전 계산기
- `FiltersBar.tsx` - 구버전 필터

#### 3. 유틸리티 및 서비스
- `center-fares.ts` - 데이터 모델, Excel 처리, 유틸리티 함수
- `api-center-fares.ts` - API 클라이언트 함수들
- `center-fare.service.ts` - 비즈니스 로직 서비스
- `useCenterFares.ts` - React Query 훅

#### 4. 테스트
- `test-center-fare-flow.js` - 센터요율 플로우 테스트

### 주요 기능:
1. **이중 요율 시스템**: 기본운임 (센터+차량+지역), 경유+지역 (센터+차량)
2. **조건부 필드**: 요율종류에 따른 필드 활성화/비활성화
3. **요율 계산기**: 기본운임 + 경유운임 + 지역운임 자동 계산
4. **Excel 가져오기/내보내기**: 템플릿 다운로드, 데이터 검증
5. **필터링**: 센터명, 요율종류별 필터
6. **CRUD 작업**: 생성, 수정, 삭제 기능

### FareRow 데이터 구조:
```typescript
interface FareRow {
  id: string
  centerId: string
  centerName: string
  vehicleTypeId: string
  vehicleTypeName: string
  region: string
  fareType: '기본운임' | '경유+지역'
  baseFare?: number
  extraStopFee?: number
  extraRegionFee?: number
  createdAt: string
}
```