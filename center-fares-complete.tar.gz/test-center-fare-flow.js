#!/usr/bin/env node

/**
 * Test script for Center Fare Registration Flow
 * Tests the complete flow: quote → missing rates → register → recalculate
 */

const API_BASE = 'http://localhost:3000/api'

// Test data
const testQuote = {
  centerId: "test-center-id",
  vehicleType: "1TON",
  regions: ["부산", "대구"],
  stopCount: 2,
  extras: {
    regionMove: 10000,
    stopExtra: 5000,
    misc: 0
  },
  isNegotiated: false
}

const testCenterFare = {
  centerId: "test-center-id",
  vehicleType: "1TON",
  region: "부산",
  fare: 50000
}

async function makeRequest(endpoint, options = {}) {
  const url = `${API_BASE}${endpoint}`
  console.log(`\n🔄 ${options.method || 'GET'} ${url}`)
  
  try {
    const response = await fetch(url, {
      headers: {
        'Content-Type': 'application/json',
        ...options.headers
      },
      ...options
    })
    
    const result = await response.json()
    
    console.log(`📊 Status: ${response.status}`)
    console.log(`📋 Response:`, JSON.stringify(result, null, 2))
    
    return { response, result }
  } catch (error) {
    console.error(`❌ Error:`, error.message)
    return { error }
  }
}

async function testQuoteFlow() {
  console.log('🚀 Testing Center Fare Registration Flow\n')
  console.log('=' .repeat(50))
  
  // Step 1: Try to get quote (should return 422 with missing rates)
  console.log('\n📝 Step 1: Request quote (should fail with missing rates)')
  const quoteResult = await makeRequest('/charters/requests/quote', {
    method: 'POST',
    body: JSON.stringify(testQuote)
  })
  
  if (quoteResult.response?.status === 422) {
    console.log('✅ Expected 422 response received')
    console.log('📋 Missing regions:', quoteResult.result?.error?.details?.missingRegions)
  }
  
  // Step 2: Register center fare
  console.log('\n💰 Step 2: Register center fare')
  const fareResult = await makeRequest('/center-fares', {
    method: 'POST',
    body: JSON.stringify(testCenterFare)
  })
  
  if (fareResult.response?.status === 201) {
    console.log('✅ Center fare created successfully')
  }
  
  // Step 3: Try quote again (should work partially)
  console.log('\n📝 Step 3: Request quote again (should work partially)')
  const secondQuoteResult = await makeRequest('/charters/requests/quote', {
    method: 'POST',
    body: JSON.stringify(testQuote)
  })
  
  if (secondQuoteResult.response?.status === 422) {
    console.log('✅ Still missing some rates (expected)')
    const stillMissing = secondQuoteResult.result?.error?.details?.missingRegions
    console.log('📋 Still missing:', stillMissing)
  } else if (secondQuoteResult.response?.status === 200) {
    console.log('✅ Quote calculated successfully!')
    console.log('💰 Total fare:', secondQuoteResult.result?.data?.totalFare)
  }
  
  console.log('\n' + '=' .repeat(50))
  console.log('🏁 Test completed')
}

// Run the test
testQuoteFlow().catch(console.error)